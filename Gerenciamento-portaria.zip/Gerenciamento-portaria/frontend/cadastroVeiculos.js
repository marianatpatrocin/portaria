    document.getElementById("formVeiculo").addEventListener("submit", async function (event) {
    event.preventDefault();

    const nomeDoMorador = document.getElementById('nomeMorador').value;
    const placa = document.getElementById('placa').value;
    const modelo = document.getElementById('modelo').value;
    const cor = document.getElementById('cor').value;
    const numeroDaVaga = document.getElementById('numeroVaga').value;

    const data = { nomeDoMorador, placa, modelo, cor, numeroDaVaga };

    try {
        const response = await fetch('http://localhost:3000/veiculos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            alert("Veículo cadastrado com sucesso!");
            window.location.href = "ListaVeiculos.html";
        } else {
            alert("Erro: " + result.message);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao tentar cadastrar o veículo. Verifique se o servidor está rodando.');
    }
});
