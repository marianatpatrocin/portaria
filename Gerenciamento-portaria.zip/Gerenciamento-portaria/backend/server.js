const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const connection = require('./db_config.js');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors())
app.listen(port, () => console.log(`Rodando na porta ${port}`));

// Rotas Moradores
app.post('/moradores', (request, response) => {
    const { nomeCompleto, bloco, apartamento, telefone, email, status } = request.body;

    let query = "INSERT INTO moradores (nomeCompleto, bloco, apartamento, telefone, email, status) VALUES (?, ?, ?, ?, ?, ?);"
    connection.query(query, [nomeCompleto, bloco, apartamento, telefone, email, status], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar morador!",
                data: err
            });
        } else {
            return response.status(201).json({
                success: true,
                message: "Morador cadastrado com sucesso!",
                data: results
            });
        }
    });
});

app.get('/moradores/listar', (request, response) => {
    let query = "SELECT * FROM moradores";
    connection.query(query, (err, results) => {
        if (results) {
            response.status(200).json({
                success: true,
                message: "Lista de moradores obtida com sucesso!",
                data: results
            });
        } else {
            response.status(400).json({
                success: false,
                message: "Erro ao buscar moradores!",
                data: err
            });
        }
    });
});


app.put('/moradores/editar/:id', (req, res) => {
    const { nomeCompleto, bloco, apartamento, telefone, email, status } = req.body;
    const id = parseInt(req.params.id);

    console.log("Body recebido:", req.body); 

    const sql = `
            UPDATE moradores
            SET nomeCompleto = ?, bloco = ?, apartamento = ?, telefone = ?, email = ?, status = ?
            WHERE id = ?;
        `;

    const params = [nomeCompleto, bloco, apartamento, telefone, email, status, id];

    connection.query(sql, params, (err, results) => {
        if (err) {
            return res.status(400).json({
                success: false,
                message: "Erro ao editar morador!",
                data: err
            });
        }

        return res.status(200).json({
            success: true,
            message: "Morador atualizado!",
            data: results
        });
    });
});

app.delete('/moradores/deletar/:id', (request, response) => {
    let query = "DELETE FROM moradores WHERE id = ?";
    connection.query(query, [request.params.id], (err, results) => {
        if (err) {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Erro ao excluir morador!",
                    error: err
                });
        } else {
            if (results.affectedRows > 0) {
                response.status(200).json({
                    success: true,
                    message: "Morador deletado!",
                    data: results
                });
            } else {
                response.status(404).json({
                    success: false,
                    message: "Morador não encontrado!"
                });
            }
        }
    });
});

//Rotas veículos

app.post('/veiculos', (request, response) => {
    console.log("Dados recebidos:", request.body);
    const { nomeDoMorador, placa, modelo, cor, numeroDaVaga } = request.body;

    let query = "INSERT INTO veiculos (nomeDoMorador, placa, modelo, cor, numeroDaVaga) VALUES (?, ?, ?, ?, ?);";
    connection.query(query, [nomeDoMorador, placa, modelo, cor, numeroDaVaga], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar veículo!",
                data: err
            });
        } else {
            return response.status(201).json({
                success: true,
                message: "Veículo cadastrado com sucesso!",
                data: results
            });
        }
    });
});

app.get('/veiculos/listar', (request, response) => {
    let query = "SELECT * FROM veiculos";
    connection.query(query, (err, results) => {
        if (results) {
            response.status(200).json({
                success: true,
                message: "Lista de veículos obtida com sucesso!",
                data: results
            });
        } else {
            response.status(400).json({
                success: false,
                message: "Erro ao buscar veículos!",
                data: err
            });
        }
    });
});

app.put('/veiculos/editar/:id', (request, response) => {
    const id = request.params.id;
    const { nomeDoMorador, placa, modelo, cor, numeroDaVaga } = request.body;

    const query = `
        UPDATE veiculos 
        SET nomeDoMorador = ?, placa = ?, modelo = ?, cor = ?, numeroDaVaga = ?
        WHERE id = ?
    `;

    connection.query(query, [nomeDoMorador, placa, modelo, cor, numeroDaVaga, id], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao atualizar veículo.",
                error: err
            });
        }

        return response.status(200).json({
            success: true,
            message: "Veículo atualizado com sucesso!",
            data: results
        });
    });
});


app.delete('/veiculos/deletar/:id', (request, response) => {
    let query = "DELETE FROM veiculos WHERE id = ?";
    connection.query(query, [request.params.id], (err, results) => {
        if (err) {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Erro ao excluir carro",
                    error: err
                });
        } else {
            if (results.affectedRows > 0) {
                response.status(200).json({
                    success: true,
                    message: "Carro deletado",
                    data: results
                });
            } else {
                response.status(404).json({
                    success: false,
                    message: "Carro não encontrado"
                });
            }
        }
    });
});