async function atualizarTotais() {
    try {
      const moradoresRes = await fetch("http://localhost:3000/moradores/listar");
      const veiculosRes = await fetch("http://localhost:3000/veiculos/listar");
  
      const moradoresData = await moradoresRes.json();
      const veiculosData = await veiculosRes.json();
  
      const totalMoradores = moradoresData.data.length;
      const totalVeiculos = veiculosData.data.length;
  
      document.getElementById("total-moradores").textContent = totalMoradores;
      document.getElementById("total-veiculos").textContent = totalVeiculos;
    } catch (error) {
      console.error("Erro ao buscar dados:", error);
    }
  }
  
  window.onload = atualizarTotais;
  