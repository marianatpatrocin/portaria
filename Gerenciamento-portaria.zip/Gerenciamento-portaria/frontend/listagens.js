// Listar Moradores
async function carregarMoradores() {
    const response = await fetch("http://localhost:3000/moradores/listar");
    const moradores = await response.json();
    const tabela = document.querySelector("#Moradores");
    tabela.innerHTML = "";
  
    console.log(moradores.data)
    moradores.data.forEach(m => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${m.nomeCompleto}</td>
        <td>${m.bloco}</td>
        <td>${m.apartamento}</td>
        <td>${m.telefone}</td>
        <td>${m.email}</td>
        <td>${m.Status}</td>
      `;
      tabela.appendChild(row);
    });
  }
  
  if (document.getElementById("Moradores")) carregarMoradores();
  
  // Listar Veículos
  async function carregarVeiculos() {
    const response = await fetch("http://localhost:3000/veiculos/listar");
    const veiculos = await response.json();
    const tabela = document.querySelector("#Veículos");
    tabela.innerHTML = "";
  
    veiculos.data.forEach(v => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${v.nomeDoMorador}</td>
        <td>${v.placa}</td>
        <td>${v.modelo}</td>
        <td>${v.cor}</td>
        <td>${v.numeroDaVaga}</td>
      `;
      tabela.appendChild(row);
    });
  }
  
  if (document.getElementById("Veículos")) carregarVeiculos();
